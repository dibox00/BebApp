import json
import os
from typing import List, Dict, Optional

class ProductManager:
    def __init__(self, data_file='data/products.json'):
        self.data_file = data_file
        self.ensure_data_file_exists()
    
    def ensure_data_file_exists(self):
        """Ensure the data directory and file exist"""
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
        if not os.path.exists(self.data_file):
            # Create initial empty products file
            with open(self.data_file, 'w') as f:
                json.dump([], f)
    
    def load_products(self) -> List[Dict]:
        """Load products from JSON file"""
        try:
            with open(self.data_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    def save_products(self, products: List[Dict]):
        """Save products to JSON file"""
        with open(self.data_file, 'w') as f:
            json.dump(products, f, indent=2)
    
    def get_all_products(self) -> List[Dict]:
        """Get all products"""
        return self.load_products()
    
    def get_product_by_id(self, product_id: int) -> Optional[Dict]:
        """Get a specific product by ID"""
        products = self.load_products()
        for product in products:
            if product.get('id') == product_id:
                return product
        return None
    
    def search_products(self, query: str) -> List[Dict]:
        """Search products by name or description"""
        products = self.load_products()
        query = query.lower()
        return [
            product for product in products
            if query in product.get('name', '').lower() or 
               query in product.get('description', '').lower()
        ]
    
    def filter_by_category(self, category: str) -> List[Dict]:
        """Filter products by category"""
        products = self.load_products()
        return [
            product for product in products
            if product.get('category', '').lower() == category.lower()
        ]
    
    def get_categories(self) -> List[str]:
        """Get all unique categories"""
        products = self.load_products()
        categories = set()
        for product in products:
            if product.get('category'):
                categories.add(product['category'])
        return sorted(list(categories))
    
    def update_stock(self, product_id: int, quantity: int) -> bool:
        """Update product stock"""
        products = self.load_products()
        for product in products:
            if product.get('id') == product_id:
                current_stock = product.get('stock', 0)
                new_stock = current_stock - quantity
                if new_stock >= 0:
                    product['stock'] = new_stock
                    self.save_products(products)
                    return True
                return False
        return False

class CartManager:
    @staticmethod
    def add_to_cart(session, product_id: int, quantity: int = 1):
        """Add item to cart stored in session"""
        if 'cart' not in session:
            session['cart'] = {}
        
        cart = session['cart']
        product_id = str(product_id)
        
        if product_id in cart:
            cart[product_id] += quantity
        else:
            cart[product_id] = quantity
        
        session['cart'] = cart
        session.modified = True
    
    @staticmethod
    def remove_from_cart(session, product_id: int):
        """Remove item from cart"""
        if 'cart' in session:
            cart = session['cart']
            product_id = str(product_id)
            if product_id in cart:
                del cart[product_id]
                session['cart'] = cart
                session.modified = True
    
    @staticmethod
    def update_cart_quantity(session, product_id: int, quantity: int):
        """Update quantity of item in cart"""
        if 'cart' in session:
            cart = session['cart']
            product_id = str(product_id)
            if quantity <= 0:
                CartManager.remove_from_cart(session, int(product_id))
            else:
                cart[product_id] = quantity
                session['cart'] = cart
                session.modified = True
    
    @staticmethod
    def get_cart_items(session) -> List[Dict]:
        """Get cart items with product details"""
        if 'cart' not in session:
            return []
        
        cart = session['cart']
        product_manager = ProductManager()
        cart_items = []
        
        for product_id, quantity in cart.items():
            product = product_manager.get_product_by_id(int(product_id))
            if product:
                cart_item = product.copy()
                cart_item['cart_quantity'] = quantity
                cart_item['total_price'] = product['price'] * quantity
                cart_items.append(cart_item)
        
        return cart_items
    
    @staticmethod
    def get_cart_total(session) -> float:
        """Calculate total cart value"""
        cart_items = CartManager.get_cart_items(session)
        return sum(item['total_price'] for item in cart_items)
    
    @staticmethod
    def get_cart_count(session) -> int:
        """Get total number of items in cart"""
        if 'cart' not in session:
            return 0
        return sum(session['cart'].values())
    
    @staticmethod
    def clear_cart(session):
        """Clear all items from cart"""
        session['cart'] = {}
        session.modified = True
