from flask import render_template, request, redirect, url_for, session, flash, jsonify
from app import app
from models import ProductManager, CartManager
import logging

# Initialize managers
product_manager = ProductManager()
cart_manager = CartManager()

@app.route('/')
def index():
    """Home page with product catalog"""
    search_query = request.args.get('search', '')
    category = request.args.get('category', '')
    
    if search_query:
        products = product_manager.search_products(search_query)
    elif category:
        products = product_manager.filter_by_category(category)
    else:
        products = product_manager.get_all_products()
    
    categories = product_manager.get_categories()
    cart_count = cart_manager.get_cart_count(session)
    
    return render_template('index.html', 
                         products=products, 
                         categories=categories,
                         current_category=category,
                         search_query=search_query,
                         cart_count=cart_count)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    """Product detail page"""
    product = product_manager.get_product_by_id(product_id)
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('index'))
    
    cart_count = cart_manager.get_cart_count(session)
    return render_template('product.html', product=product, cart_count=cart_count)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    """Add item to cart"""
    try:
        product_id = int(request.form.get('product_id'))
        quantity = int(request.form.get('quantity', 1))
        
        # Check if product exists and has sufficient stock
        product = product_manager.get_product_by_id(product_id)
        if not product:
            flash('Product not found', 'error')
            return redirect(url_for('index'))
        
        if product.get('stock', 0) < quantity:
            flash('Insufficient stock available', 'error')
            return redirect(url_for('product_detail', product_id=product_id))
        
        cart_manager.add_to_cart(session, product_id, quantity)
        flash(f'{product["name"]} added to cart!', 'success')
        
        # Redirect back to the referring page or product page
        return redirect(request.form.get('redirect_url', url_for('product_detail', product_id=product_id)))
        
    except (ValueError, TypeError) as e:
        logging.error(f"Error adding to cart: {e}")
        flash('Error adding item to cart', 'error')
        return redirect(url_for('index'))

@app.route('/cart')
def cart():
    """Shopping cart page"""
    cart_items = cart_manager.get_cart_items(session)
    cart_total = cart_manager.get_cart_total(session)
    cart_count = cart_manager.get_cart_count(session)
    
    return render_template('cart.html', 
                         cart_items=cart_items, 
                         cart_total=cart_total,
                         cart_count=cart_count)

@app.route('/update_cart', methods=['POST'])
def update_cart():
    """Update cart item quantity"""
    try:
        product_id = int(request.form.get('product_id'))
        quantity = int(request.form.get('quantity', 0))
        
        if quantity <= 0:
            cart_manager.remove_from_cart(session, product_id)
            flash('Item removed from cart', 'info')
        else:
            # Check stock availability
            product = product_manager.get_product_by_id(product_id)
            if product and product.get('stock', 0) >= quantity:
                cart_manager.update_cart_quantity(session, product_id, quantity)
                flash('Cart updated', 'success')
            else:
                flash('Insufficient stock available', 'error')
        
    except (ValueError, TypeError) as e:
        logging.error(f"Error updating cart: {e}")
        flash('Error updating cart', 'error')
    
    return redirect(url_for('cart'))

@app.route('/remove_from_cart/<int:product_id>')
def remove_from_cart(product_id):
    """Remove item from cart"""
    try:
        product = product_manager.get_product_by_id(product_id)
        cart_manager.remove_from_cart(session, product_id)
        if product:
            flash(f'{product["name"]} removed from cart', 'info')
        else:
            flash('Item removed from cart', 'info')
    except Exception as e:
        logging.error(f"Error removing from cart: {e}")
        flash('Error removing item from cart', 'error')
    
    return redirect(url_for('cart'))

@app.route('/checkout')
def checkout():
    """Checkout page"""
    cart_items = cart_manager.get_cart_items(session)
    if not cart_items:
        flash('Your cart is empty', 'info')
        return redirect(url_for('index'))
    
    cart_total = cart_manager.get_cart_total(session)
    cart_count = cart_manager.get_cart_count(session)
    
    return render_template('checkout.html', 
                         cart_items=cart_items, 
                         cart_total=cart_total,
                         cart_count=cart_count)

@app.route('/process_order', methods=['POST'])
def process_order():
    """Process the order (mocked checkout)"""
    try:
        cart_items = cart_manager.get_cart_items(session)
        if not cart_items:
            flash('Your cart is empty', 'error')
            return redirect(url_for('index'))
        
        # Get form data
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        address = request.form.get('address', '').strip()
        
        if not all([name, email, address]):
            flash('Please fill in all required fields', 'error')
            return redirect(url_for('checkout'))
        
        # Update stock for each item (simulate order processing)
        for item in cart_items:
            success = product_manager.update_stock(item['id'], item['cart_quantity'])
            if not success:
                flash(f'Error processing order: {item["name"]} is out of stock', 'error')
                return redirect(url_for('cart'))
        
        # Clear cart and show success message
        cart_manager.clear_cart(session)
        flash(f'Order placed successfully! Thank you for your purchase, {name}!', 'success')
        
        return redirect(url_for('index'))
        
    except Exception as e:
        logging.error(f"Error processing order: {e}")
        flash('Error processing your order. Please try again.', 'error')
        return redirect(url_for('checkout'))

@app.errorhandler(404)
def not_found_error(error):
    """Handle 404 errors"""
    cart_count = cart_manager.get_cart_count(session)
    return render_template('base.html', cart_count=cart_count), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    cart_count = cart_manager.get_cart_count(session)
    return render_template('base.html', cart_count=cart_count), 500

# Initialize with sample data if the products file is empty
def initialize_data():
    """Initialize with sample fashion products if database is empty"""
    products = product_manager.get_all_products()
    if not products:
        sample_products = [
            {
                "id": 1,
                "name": "Classic Denim Jacket",
                "description": "A timeless denim jacket perfect for casual outings. Made from high-quality cotton denim with a comfortable fit.",
                "price": 89.99,
                "category": "Outerwear",
                "stock": 15,
                "image": "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop"
            },
            {
                "id": 2,
                "name": "Elegant Black Dress",
                "description": "Sophisticated black dress suitable for both office and evening wear. Features a flattering silhouette and premium fabric.",
                "price": 129.99,
                "category": "Dresses",
                "stock": 8,
                "image": "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop"
            },
            {
                "id": 3,
                "name": "Casual Cotton T-Shirt",
                "description": "Comfortable and breathable cotton t-shirt available in multiple colors. Perfect for everyday wear.",
                "price": 24.99,
                "category": "T-Shirts",
                "stock": 25,
                "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop"
            },
            {
                "id": 4,
                "name": "Slim Fit Jeans",
                "description": "Modern slim-fit jeans crafted from premium denim. Offers comfort and style for any occasion.",
                "price": 79.99,
                "category": "Jeans",
                "stock": 12,
                "image": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop"
            },
            {
                "id": 5,
                "name": "Wool Blend Sweater",
                "description": "Cozy wool blend sweater perfect for cooler weather. Features a classic design and soft texture.",
                "price": 94.99,
                "category": "Sweaters",
                "stock": 10,
                "image": "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=400&fit=crop"
            },
            {
                "id": 6,
                "name": "Summer Floral Blouse",
                "description": "Light and airy floral blouse perfect for summer days. Features a beautiful print and comfortable fit.",
                "price": 54.99,
                "category": "Blouses",
                "stock": 18,
                "image": "https://images.unsplash.com/photo-1485968579580-b6d72834b5a4?w=400&h=400&fit=crop"
            },
            {
                "id": 7,
                "name": "Leather Boots",
                "description": "Durable leather boots with excellent craftsmanship. Perfect for both casual and semi-formal occasions.",
                "price": 149.99,
                "category": "Footwear",
                "stock": 7,
                "image": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop"
            },
            {
                "id": 8,
                "name": "Sports Sneakers",
                "description": "Comfortable sports sneakers designed for active lifestyles. Features cushioned sole and breathable material.",
                "price": 119.99,
                "category": "Footwear",
                "stock": 20,
                "image": "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=400&h=400&fit=crop"
            }
        ]
        product_manager.save_products(sample_products)
        logging.info("Sample products initialized")

# Call initialization when the module is loaded
initialize_data()
