// Main JavaScript file for Cloud Fashion Store

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips if Bootstrap 5 is loaded
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            if (alert.classList.contains('show')) {
                const closeButton = alert.querySelector('.btn-close');
                if (closeButton) {
                    closeButton.click();
                }
            }
        }, 5000);
    });

    // Add loading states to forms
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function() {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                const originalText = submitButton.innerHTML;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Processing...';
                
                // Re-enable after 3 seconds as fallback
                setTimeout(function() {
                    submitButton.disabled = false;
                    submitButton.innerHTML = originalText;
                }, 3000);
            }
        });
    });

    // Smooth scrolling for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add fade-in animation to cards
    const cards = document.querySelectorAll('.card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    cards.forEach(function(card) {
        observer.observe(card);
    });
});

// Category filter function
function filterByCategory(category) {
    const url = new URL(window.location);
    if (category) {
        url.searchParams.set('category', category);
    } else {
        url.searchParams.delete('category');
    }
    url.searchParams.delete('search'); // Clear search when filtering by category
    window.location.href = url.toString();
}

// Quantity controls for cart
function increaseQuantity(productId, maxStock) {
    const quantityInput = document.getElementById('quantity-' + productId);
    const currentQuantity = parseInt(quantityInput.value);
    if (currentQuantity < maxStock) {
        quantityInput.value = currentQuantity + 1;
        quantityInput.form.submit();
    }
}

function decreaseQuantity(productId) {
    const quantityInput = document.getElementById('quantity-' + productId);
    const currentQuantity = parseInt(quantityInput.value);
    if (currentQuantity > 1) {
        quantityInput.value = currentQuantity - 1;
        quantityInput.form.submit();
    } else if (currentQuantity === 1) {
        if (confirm('Remove this item from cart?')) {
            quantityInput.value = 0;
            quantityInput.form.submit();
        }
    }
}

// Shopping cart utilities
function updateCartBadge() {
    // This would typically be called after AJAX requests to update cart count
    // For now, we rely on page refreshes to update the cart count
}

// Form validation helpers
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;

    requiredFields.forEach(function(field) {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
            field.classList.add('is-valid');
        }

        // Special validation for email fields
        if (field.type === 'email' && field.value.trim() && !validateEmail(field.value)) {
            field.classList.add('is-invalid');
            isValid = false;
        }
    });

    return isValid;
}

// Search enhancement
function initializeSearch() {
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const query = this.value.trim();
            
            // Auto-submit search after 500ms of no typing
            if (query.length >= 2) {
                searchTimeout = setTimeout(function() {
                    searchInput.form.submit();
                }, 500);
            }
        });
    }
}

// Initialize search when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeSearch);

// Error handling for images
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.addEventListener('error', function() {
            this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgdmlld0JveD0iMCAwIDQwMCA0MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iNDAwIiBmaWxsPSIjRjhGOUZBIi8+CjxwYXRoIGQ9Ik0yMDAgMTUwQzE3Mi4zODYgMTUwIDE1MCAyMjIuMzg2IDE1MCAyNTBDMTUwIDI3Ny42MTQgMTcyLjM4NiAzMDAgMjAwIDMwMEMyMjcuNjE0IDMwMCAyNTAgMjc3LjYxNCAyNTAgMjUwQzI1MCAyMjIuMzg2IDIyNy42MTQgMjAwIDIwMCAyMDBaIiBmaWxsPSIjRTVFN0VCIi8+CjxwYXRoIGQ9Ik0yMDAgMjEwQzIxNi41NjkgMjEwIDIzMCAyMjYuNDMxIDIzMCAyNDNDMjMwIDI1OS41NjkgMjE2LjU2OSAyNzYgMjAwIDI3NkMxODMuNDMxIDI3NiAxNzAgMjU5LjU2OSAxNzAgMjQzQzE3MCAyMjYuNDMxIDE4My40MzEgMjEwIDIwMCAyMTBaIiBmaWxsPSIjRjNGNEY2Ii8+Cjx0ZXh0IHg9IjIwMCIgeT0iMzMwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBTZWdvZSBVSSwgUm9ib3RvLCBPeHlnZW4sIFVidW50dSwgQ2FudGFyZWxsLCBvcGVuIHNhbnMsIGhlbHZldGljYSBuZXVlLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjOUM5Q0EzIj5JbWFnZSBub3QgZm91bmQ8L3RleHQ+Cjwvc3ZnPgo=';
            this.alt = 'Image not available';
        });
    });
});
