# Cloud Fashion Store 🛍️☁️

## Descrizione
Progetto cloud di vendita vestiti online sviluppato in Python usando Flask. L'app è containerizzata con Docker, utilizza un database PostgreSQL, esporta metriche Prometheus per l'autoscaling e bilanciamento del carico (via NGINX), pronta per il deploy su cloud (es. AWS).

## Requisiti
- Frontend minimale in HTML/CSS (Bootstrap)
- Backend Flask con CRUD per prodotti e carrello
- Database PostgreSQL per la persistenza
- Prometheus per metriche
- Autoscaling e load balancing simulabili localmente
- Docker + Docker Compose
- Deploy cloud-ready (AWS/VM locali)

## Comandi base

1. Clona il progetto
```
git clone https://github.com/tuo-username/cloud-fashion-store.git
cd cloud-fashion-store
```

2. Avvia Docker Compose
```
docker-compose up --build
```

3. Visita il sito su http://localhost:5000

## Struttura
```
.
├── app/
│   ├── __init__.py
│   ├── routes.py
│   ├── models.py
│   ├── forms.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── product_detail.html
│   │   ├── cart.html
│   │   └── add_product.html
│   └── static/
│       └── style.css
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── prometheus.yml
