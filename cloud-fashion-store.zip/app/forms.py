from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, SelectField, SubmitField
from wtforms.validators import DataRequired

class ProductForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired()])
    price = FloatField('Prezzo', validators=[DataRequired()])
    category = SelectField('Categoria', choices=[
        ('Uomo', 'Uomo'), ('Donna', 'Donna'), ('Bambino', 'Bambino')
    ])
    image_url = StringField('URL Immagine')
    submit = SubmitField('Aggiungi')
