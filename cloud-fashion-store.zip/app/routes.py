from flask import Blueprint, render_template, request, redirect, url_for, session
from . import db, REQUEST_COUNT
from .models import Product, CartItem
from .forms import ProductForm

main = Blueprint('main', __name__)

@main.before_request
def before_request():
    REQUEST_COUNT.inc()

@main.route('/')
def index():
    category = request.args.get('category')
    search = request.args.get('search', '').lower()
    query = Product.query
    if category:
        query = query.filter_by(category=category)
    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))
    products = query.all()
    return render_template("index.html", products=products, category=category or '', search=search)

@main.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    return render_template("product_detail.html", product=product)

@main.route('/add', methods=['GET', 'POST'])
def add_product():
    form = ProductForm()
    if form.validate_on_submit():
        new_product = Product(
            name=form.name.data,
            price=form.price.data,
            category=form.category.data,
            image_url=form.image_url.data
        )
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('main.index'))
    return render_template("add_product.html", form=form)

@main.route('/cart')
def view_cart():
    cart = session.get('cart', {})
    product_ids = list(cart.keys())
    items = Product.query.filter(Product.id.in_(product_ids)).all() if product_ids else []
    items_with_qty = [(item, cart.get(str(item.id), 0)) for item in items]
    total = sum(item.price * qty for item, qty in items_with_qty)
    return render_template("cart.html", items=items_with_qty, total=total)

@main.route('/cart/add/<int:product_id>')
def add_to_cart(product_id):
    cart = session.get('cart', {})
    pid = str(product_id)
    cart[pid] = cart.get(pid, 0) + 1
    session['cart'] = cart
    return redirect(url_for('main.index'))
